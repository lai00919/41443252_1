QT += widgets
CONFIG += c++17
QT +=core gui network
SOURCES += \
    main.cpp \
    tcpfileserver.cpp

HEADERS += \
    tcpfileserver.h
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
